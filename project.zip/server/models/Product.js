import mongoose from "mongoose";

const descriptionSectionSchema = new mongoose.Schema(
  {
    title: { type: String, trim: true, default: "" },
    content: { type: String, trim: true, default: "" },
  },
  { _id: false }
);

const productSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    // Plain-text fallback / search index (auto-synced from sections when possible)
    description: { type: String, default: "" },
    // Up to 4 structured sections the vendor controls
    descriptionSections: {
      type: [descriptionSectionSchema],
      default: [],
      validate: {
        validator(v) {
          return !v || v.length <= 4;
        },
        message: "Maximum 4 description sections allowed",
      },
    },
    // How the customer product page should render the sections
    descriptionStyle: {
      type: String,
      enum: ["paragraphs", "cards", "tabs", "accordion", "list"],
      default: "paragraphs",
    },
    price: { type: Number, required: true, min: 0 },
    stock: { type: Number, required: true, min: 0, default: 0 },
    images: [{ type: String }],
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
      required: true,
    },
    vendor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Vendor",
      required: true,
    },
    isPublished: { type: Boolean, default: true },
    views: { type: Number, default: 0 },
    ratings: {
      average: { type: Number, default: 0 },
      count: { type: Number, default: 0 },
    },
    // Percentage discount set by the vendor. 0 means no discount.
    discountPercentage: { type: Number, default: 0, min: 0, max: 90 },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// The actual price a customer pays, after the vendor's discount is applied.
productSchema.virtual("finalPrice").get(function () {
  if (this.discountPercentage > 0) {
    const discounted =
      this.price - (this.price * this.discountPercentage) / 100;
    return Math.round(discounted * 100) / 100;
  }
  return this.price;
});

productSchema.index({ isPublished: 1, createdAt: -1 });
productSchema.index({ isPublished: 1, price: 1 });
productSchema.index({ isPublished: 1, category: 1 });
productSchema.index({ vendor: 1 });
productSchema.index({ title: "text", description: "text" });

export default mongoose.model("Product", productSchema);
